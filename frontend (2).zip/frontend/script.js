const socket = io("http://localhost:5000");

const board = document.getElementById("board");
const statusText = document.getElementById("status");

let gameMode = "ai";
let playerSymbol = "X";
let roomId = "";

let gameState = ["","","","","","","","",""];
let currentPlayer = "X";
let gameActive = true;

let xWins = 0, oWins = 0, draws = 0;

const patterns = [
 [0,1,2],[3,4,5],[6,7,8],
 [0,3,6],[1,4,7],[2,5,8],
 [0,4,8],[2,4,6]
];

document.getElementById("mode").addEventListener("change", e=>{
    gameMode = e.target.value;
    restartGame();
});

function createBoard(){
    board.innerHTML="";
    for(let i=0;i<9;i++){
        let cell=document.createElement("div");
        cell.classList.add("cell");
        cell.dataset.index=i;
        cell.onclick=handleClick;
        board.appendChild(cell);
    }
}

function handleClick(){
    let index=this.dataset.index;

    if(gameState[index]!=="" || !gameActive) return;

    if(gameMode==="multi" && currentPlayer!==playerSymbol) return;

    gameState[index]=currentPlayer;
    this.textContent=currentPlayer;

    playSound("click");

    if(gameMode==="multi"){
        socket.emit("move",{index,player:currentPlayer,roomId});
    }

    checkWinner();

    if(gameMode==="ai" && currentPlayer==="O" && gameActive){
        setTimeout(aiMove,500);
    }
}

function checkWinner(){
    for(let p of patterns){
        let [a,b,c]=p;
        if(gameState[a] && gameState[a]===gameState[b] && gameState[a]===gameState[c]){
            statusText.textContent=gameState[a]+" Wins!";
            gameActive=false;

            p.forEach(i=>{
                document.querySelectorAll(".cell")[i].classList.add("win");
            });

            if(gameState[a]==="X") xWins++; else oWins++;
            updateScore();
            saveGame(gameState[a]);
            playSound("win");
            return;
        }
    }

    if(!gameState.includes("")){
        statusText.textContent="Draw!";
        draws++; updateScore();
        playSound("draw");
        return;
    }

    currentPlayer=currentPlayer==="X"?"O":"X";
    statusText.textContent="Player "+currentPlayer+" Turn";
}

function updateScore(){
    document.getElementById("xWins").textContent=xWins;
    document.getElementById("oWins").textContent=oWins;
    document.getElementById("draws").textContent=draws;
}

function restartGame(){
    gameState=["","","","","","","","",""];
    currentPlayer="X";
    gameActive=true;
    statusText.textContent="Player X Turn";
    createBoard();
}

function aiMove(){
    let empty=gameState.map((v,i)=>v===""?i:null).filter(v=>v!==null);
    let move=empty[Math.floor(Math.random()*empty.length)];
    document.querySelectorAll(".cell")[move].click();
}

function createRoom(){
    roomId=Math.random().toString(36).substr(2,5);
    socket.emit("createRoom",{roomId});
    alert("Room: "+roomId);
}

function joinRoom(){
    roomId=document.getElementById("roomCode").value;
    socket.emit("joinRoom",{roomId});
}

socket.on("startGame",({symbol})=>{
    playerSymbol=symbol;
    alert("You are "+symbol);
});

socket.on("move",({index,player})=>{
    gameState[index]=player;
    document.querySelectorAll(".cell")[index].textContent=player;
    checkWinner();
});

function playSound(type){
    new Audio("sounds/"+type+".mp3").play();
}

function saveGame(winner){
    fetch("http://localhost:5000/api/save",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({winner})
    });
}

createBoard();